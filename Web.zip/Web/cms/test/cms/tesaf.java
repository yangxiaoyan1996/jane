package cms;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import com.chinasofti.cms.dao.NewsDao;
import com.chinasofti.cms.dao.impl.NewsDaoImpl;

public class tesaf {

	@Test
	public void test() throws SQLException {
		NewsDao nes = new NewsDaoImpl();
		nes.getNewsTitles();
	}

}
