package cms;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Test;

import com.chinasofti.cms.dao.EmpDao;
import com.chinasofti.cms.dao.impl.EmpDaoImpl;

public class TestEmpDao {
	
//	@After
//	public void tearDown() throws Exception{
//		
//	}
	
	@Test
	public void testFindAll() throws SQLException {
		EmpDao empDao = new EmpDaoImpl();
		System.out.println(empDao.findAll(1,2));
	}

}
