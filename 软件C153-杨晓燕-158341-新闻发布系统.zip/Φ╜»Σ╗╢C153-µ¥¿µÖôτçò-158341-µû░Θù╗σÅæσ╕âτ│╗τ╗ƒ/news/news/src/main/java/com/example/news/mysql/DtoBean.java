package com.example.news.mysql;

/**
 * DTO接口标识
 * @author lingzhen on 17/9/2.
 */
public interface DtoBean {
}
